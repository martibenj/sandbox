(function () {
	'use strict';

	/**
	 * Déclaration du module des livres
	 */
	angular.module('app.book',
		// Modules injectés
		[
			'ngRoute',
			'app.book-controller',
			'app.book-service'
		])
		// Configuration des routes du service ngRoute
		.config(['$routeProvider', bookRoutes]);


	// Définition des routes.
	function bookRoutes($routeProvider) {
		$routeProvider.when('/book', {
			templateUrl: 'book/book.html'
		});
	}

})();
