(function () {

	'use strict';

	/**
	 * Déclaration du module de service d'accès aux livres
	 */
	angular.module('app.book-service', [])
		.factory('BookService', BookService);

	/**
	 * Implémentation du service.
	 */
	function BookService() {
		var idAuto = 0;

		/**
		 * Interface du service
		 */
		var service = {
			"findAll": findAll,
			"create": create,
			"remove": remove
		};


		var generateId = function () {
			idAuto++;
			return idAuto.toString();
		};

		var valeurs = [
			{"id": generateId(), "title": 'Astérix le gaulois', "description": 'Goscinny'},
			{"id": generateId(), "title": 'Luky luke - Arizona', "description": 'Morris'},
			{"id": generateId(), "title": 'Tintin au Congo', "description": 'Hergé'}
		];

		/**
		 * Recherche tous les livres disponibles.
		 * @returns Tableau de livres
		 */
		function findAll() {
			return angular.copy(valeurs);
		}

		/**
		 * Création d'un nouveau livre.
		 * @param book Le livre à créer
		 * @returns Le livre réellement créé
		 */
		function create(book) {
			var created = angular.copy(book);
			created.id = generateId();
			valeurs.push(created);
			return created;
		}

		/**
		 * Suppression d'un livre.
		 * @param id Identifiant du livre à supprimer
		 */
		function remove(id) {
			var i;
			for (i = 0; i < valeurs.length; i++) {
				if (valeurs[i].id === id.toString()) {
					valeurs.splice(i, 1);
					break;
				}
			}
		}

		return service;
	}

})();
