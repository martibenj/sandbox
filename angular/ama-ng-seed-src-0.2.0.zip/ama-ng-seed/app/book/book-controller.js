(function () {
	'use strict';

	/**
	 * Déclaration du module des livres
	 */
	angular.module('app.book-controller', ['ngRoute', 'app.book-service'])
		// Déclaration avec les services à injecter
		.controller('BookController', ['$rootScope', 'BookService', BookController]);

	// Déclaration sans les services à injecter
	//.controller('BookController', BookController);

	// Injection des services utilisés
	// BookController.$inject =  ['$rootScope', 'BookService'];

	// Implémentation du controleur
	function BookController($rootScope, BookService) {
		var vm = this;

		/**
		 * Initialisation du modèle
		 */
		vm.books = BookService.findAll();
		vm.bookToCreate = null;
		vm.bookToUpdate = null;
		vm.bookUpdated = null;

		vm.prepareToCreate = prepareToCreate;
		vm.create = create;
		vm.cancelCreate = cancelCreate;
		vm.deleteAllSelected = deleteAllSelected;
		vm.cancelDelete = cancelDelete;
		vm.markAll = markAll;
		vm.prepareToUpdate = prepareToUpdate;
		vm.update = update;
		vm.cancelUpdate = cancelUpdate;
		vm.cancelOtherAction = cancelOtherAction;

		$rootScope.titrePage = "Application exemple - Livre";

		/**
		 * Préparer la création d'un livre
		 */
		function prepareToCreate() {
			vm.cancelOtherAction("create");
			vm.bookToCreate = {};
		}

		/**
		 * Ajout d'un livre
		 */
		function create() {
			if (vm.bookToCreate) {
				var title = vm.bookToCreate.title;
				if (title && title.trim().length > 0) {
					var created = BookService.create(vm.bookToCreate);
					vm.books.push(created);
					vm.bookToCreate = null;
				}
			}
		}

		/**
		 * Annuler la création d'un livre
		 */
		function cancelCreate() {
			vm.bookToCreate = null;
		}

		/**
		 * Suppression des livres cochés
		 */
		function deleteAllSelected() {
			vm.cancelOtherAction("delete");
			var toDelete = [];
			angular.forEach(vm.books, function (p_Book) {
				if (p_Book.mark) {
					this.push(p_Book);
				}
			}, toDelete);
			angular.forEach(toDelete, function (p_Book) {
				BookService.remove(p_Book.id);
				vm.books.splice(vm.books.indexOf(p_Book), 1);
			});
		}

		/**
		 * Annuler la suppression des livres
		 */
		function cancelDelete() {
			vm.markAll(false);
		}

		/**
		 * Cocher / Décocher tous les livres
		 */
		function markAll(p_Mark) {
			vm.books.forEach(function (p_Book) {
				p_Book.mark = p_Mark;
			});
		}

		/**
		 * Préparer la modification d'un livre
		 */
		function prepareToUpdate(p_Book) {
			vm.cancelOtherAction("update");
			vm.bookToUpdate = p_Book;
			vm.bookUpdated = angular.copy(p_Book);
		}

		/**
		 * Modifier un livre
		 */
		function update() {
			angular.copy(vm.bookUpdated, vm.bookToUpdate);
			vm.bookUpdated = null;
			vm.bookToUpdate = null;
		}

		/**
		 * Annuler la modification d'un livre
		 */
		function cancelUpdate() {
			vm.bookUpdated = null;
			vm.bookToUpdate = null;
		}

		/**
		 * Annuler toutes les autres actions en cours
		 */
		function cancelOtherAction(p_Current) {
			if ("create" !== p_Current) {
				vm.cancelCreate();
			}
			if ("update" !== p_Current) {
				vm.cancelUpdate();
			}
			if ("delete" !== p_Current) {
				vm.cancelDelete();
			}
		}
	}

})();
