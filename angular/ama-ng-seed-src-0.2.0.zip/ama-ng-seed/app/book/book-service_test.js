'use strict';

/**
 * Test du module @link{BookService}.
 */
describe("Ma suite (ensemble) de tests pour le service BookService", function () {
	beforeEach(module('app.book-service'));

	// TODO A supprimer
	it("contains spec with an expectation", function () {
		expect(true).toBe(true);
	});

	/**
	 * Test de @link{BookService.create(book)}.
	 */
	it("doit créer un livre et le renvoyer identifié", inject(function (BookService) {
		expect(BookService.findAll().length).toEqual(3);

		var bookToCreate = {"title": 'Tintin au Tibet', "description": 'Hergé'};
		var bookCreated = {"id": "4", "title": 'Tintin au Tibet', "description": 'Hergé'};

		expect(BookService.create(bookToCreate)).toEqual(bookCreated);
		expect(BookService.findAll().length).toEqual(4);
		expect(BookService.findAll()[3]).toEqual({"id": "4", "title": 'Tintin au Tibet', "description": 'Hergé'});
	}));

	/**
	 * Test de @link{BookService.findAll()}.
	 */
	it("doit retourner 3 livres", inject(function (BookService) {
		expect(BookService.findAll().length).toEqual(3);

		var attendu = [
			{"id": "1", "title": 'Astérix le gaulois', "description": 'Goscinny'},
			{"id": "2", "title": 'Luky luke - Arizona', "description": 'Morris'},
			{"id": "3", "title": 'Tintin au Congo', "description": 'Hergé'}
		];
		expect(BookService.findAll()).toEqual(attendu);
	}));

	/**
	 * Test de @link{BookService.delete(id)}.
	 */
	it("doit supprimer un livre", inject(function (BookService) {
		expect(BookService.findAll().length).toEqual(3);

		var books;

		BookService.remove(2);
		books = BookService.findAll();
		expect(books.length).toEqual(2);
		expect(books[0].id).toEqual("1");
		expect(books[1].id).toEqual("3");

		BookService.remove(1);
		books = BookService.findAll();
		expect(books.length).toEqual(1);
		expect(books[0].id).toEqual("3");

		BookService.remove(10);
		books = BookService.findAll();
		expect(books.length).toEqual(1);

		BookService.remove(3);
		books = BookService.findAll();
		expect(books.length).toEqual(0);
	}));

});

