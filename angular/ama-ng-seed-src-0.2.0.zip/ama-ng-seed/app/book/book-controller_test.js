'use strict';

/**
 * Test du module @link{BookController}.
 */
describe("Ma suite (ensemble) de tests pour le controleur BookController", function () {
	var controller;

	beforeEach(module('app.book-controller'));
	beforeEach(module('app.book-service'));

	/**
	 * Test : init
	 */
	it("doit initialiser correctement le scope avec le vrai service", inject(function ($controller, _BookService_) {
		controller = $controller('BookController', {
			controller: controller,
			BookService: _BookService_
		});

		expect(controller.books.length).toEqual(3);
		expect(controller.bookToCreate).toBeNull();
		expect(controller.bookToUpdate).toBeNull();
		expect(controller.bookUpdated).toBeNull();
	}));

	/**
	 * Test de @link{BookController#prepareToCreate()}.
	 */
	it("doit préparer le scope pour la création d'un livre", inject(function ($controller, _BookService_) {

		controller = $controller('BookController', {
			controller: controller,
			BookService: _BookService_
		});

		controller.prepareToCreate();

		expect(controller.books.length).toEqual(3);
		expect(controller.bookToCreate).toEqual({});
		expect(controller.bookToUpdate).toBeNull();
		expect(controller.bookUpdated).toBeNull();
	}));

	/**
	 * Test de @link{BookController#create()}.
	 */
	it("doit ajouter un livre dans le scope et appeler le service d'ajout du livre", inject(function ($controller, _BookService_) {

		spyOn(_BookService_, "create").and.callThrough();

		controller = $controller('BookController', {
			controller: controller,
			BookService: _BookService_
		});

		controller.create();
		expect(controller.books.length).toEqual(3);
		expect(controller.bookToCreate).toBeNull();
		expect(_BookService_.create).not.toHaveBeenCalled();


		controller.bookToCreate = {"title": 'Nouveau', "description": 'Nouvelle'};
		controller.create();
		expect(controller.books.length).toEqual(4);
		expect(controller.books[3]).toEqual({"id": "4", "title": 'Nouveau', "description": 'Nouvelle'});
		expect(controller.bookToCreate).toBeNull();
		expect(_BookService_.create).toHaveBeenCalled();

		expect(controller.bookToUpdate).toBeNull();
		expect(controller.bookUpdated).toBeNull();
	}));

	/**
	 * Test de @link{BookController#cancelCreate()}.
	 */
	it("doit annuler la préparation d'un livre pour sa création dans le scope", inject(function ($controller, _BookService_) {

		controller = $controller('BookController', {
			controller: controller,
			BookService: _BookService_
		});

		controller.prepareToCreate();
		controller.cancelCreate();
		expect(controller.bookToCreate).toBeNull();

		expect(controller.books.length).toEqual(3);
		expect(controller.bookToUpdate).toBeNull();
		expect(controller.bookUpdated).toBeNull();
	}));

	/**
	 * Test de @link{BookController#prepareToUpdate()}.
	 */
	it("doit préparer le scope pour la modification d'un livre", inject(function ($controller, _BookService_) {

		controller = $controller('BookController', {
			controller: controller,
			BookService: _BookService_
		});

		var book = {"id": "2", "title": 'Luky luke - Arizona', "description": 'Morris'};
		controller.prepareToUpdate(book);

		expect(controller.bookToUpdate).toEqual(book);
		expect(controller.bookToUpdate).toBe(book);
		expect(controller.bookUpdated).toEqual(book);
		expect(controller.bookUpdated).not.toBe(book);

		expect(controller.books.length).toEqual(3);
		expect(controller.bookToCreate).toBeNull();
	}));

	/**
	 * Test de @link{BookController#update()}.
	 */
	it("doit modifier un livre dans le scope", inject(function ($controller, _BookService_) {

		controller = $controller('BookController', {
			controller: controller,
			BookService: _BookService_
		});

		controller.prepareToUpdate(controller.books[1]);
		controller.bookUpdated.description = 'TOTO';
		controller.update();

		expect(controller.books.length).toEqual(3);
		expect(controller.books[1]).toEqual({
			"id": "2",
			"title": 'Luky luke - Arizona',
			"description": 'TOTO',
			mark: false
		});
		expect(controller.bookToUpdate).toBeNull();
		expect(controller.bookUpdated).toBeNull();

		expect(controller.bookToCreate).toBeNull();
	}));

	/**
	 * Test de @link{BookController#cancelUpdate()}.
	 */
	it("doit annuler la modification d'un livre dans le scope", inject(function ($controller, _BookService_) {

		controller = $controller('BookController', {
			controller: controller,
			BookService: _BookService_
		});

		controller.prepareToUpdate(controller.books[1]);
		controller.bookUpdated.description = 'TOTO';
		controller.cancelUpdate();

		expect(controller.books.length).toEqual(3);
		expect(controller.books[1]).toEqual({
			"id": "2",
			"title": 'Luky luke - Arizona',
			"description": 'Morris',
			mark: false
		});
		expect(controller.bookToUpdate).toBeNull();
		expect(controller.bookUpdated).toBeNull();

		expect(controller.bookToCreate).toBeNull();
	}));

	/**
	 * Test de @link{BookController#markAll()}.
	 */
	it("doit marquer tous les livres dans le scope", inject(function ($controller, _BookService_) {

		controller = $controller('BookController', {
			controller: controller,
			BookService: _BookService_
		});

		var defaultBooks = [
			{"id": "1", "title": 'Astérix le gaulois', "description": 'Goscinny'},
			{"id": "2", "title": 'Luky luke - Arizona', "description": 'Morris'},
			{"id": "3", "title": 'Tintin au Congo', "description": 'Hergé'}
		];
		expect(controller.books).toEqual(defaultBooks);

		var markedBooks = [
			{"id": "1", "title": 'Astérix le gaulois', "description": 'Goscinny', "mark": true},
			{"id": "2", "title": 'Luky luke - Arizona', "description": 'Morris', "mark": true},
			{"id": "3", "title": 'Tintin au Congo', "description": 'Hergé', "mark": true}
		];

		controller.markAll(true);
		expect(controller.books).toEqual(markedBooks);

		var unmarkedBooks = [
			{"id": "1", "title": 'Astérix le gaulois', "description": 'Goscinny', "mark": false},
			{"id": "2", "title": 'Luky luke - Arizona', "description": 'Morris', "mark": false},
			{"id": "3", "title": 'Tintin au Congo', "description": 'Hergé', "mark": false}
		];

		controller.markAll(false);
		expect(controller.books).toEqual(unmarkedBooks);

	}));

	/**
	 * Test de @link{BookController#markAll()}.
	 */
	it("doit supprimer un livre dans le scope et appeler le service pour le supprimer", inject(function ($controller, _BookService_) {

		spyOn(_BookService_, "remove");

		controller = controller = $controller('BookController', {
			controller: controller,
			BookService: _BookService_
		});

		controller.books[1].mark = true;
		controller.deleteAllSelected();

		expect(controller.books.length).toEqual(2);

		expect(_BookService_.remove).toHaveBeenCalled();
		expect(_BookService_.remove).toHaveBeenCalledWith('2');
	}));


	// TODO tester les méthodes @link{BookController#cancelOtherAction} et @link{BookController#cancelDelete}.

});

