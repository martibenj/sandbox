(function () {
	'use strict';

	/**
	 * Déclaration du module de l'application
	 */
	angular.module('app',
		// Modules injectés
		[
			'ngRoute',
			'app.book',
			'app.cd'
		])
		// Déclaration du controleur
		.controller('AppController', AppController);

	// Injection des services utilisés
	AppController.$inject = ['$rootScope'];

	// Implémentation du controleur.
	function AppController($rootScope) {
		/**
		 * Initialisation du modèle
		 */
		$rootScope.titrePage = "Application exemple";
	}
})();

