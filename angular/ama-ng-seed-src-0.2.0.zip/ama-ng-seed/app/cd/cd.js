(function () {
	'use strict';


	// Déclaration du module des CDs
	angular.module('app.cd', ['ngRoute', 'app.cd-controller'])
		.config(['$routeProvider', cdRoutes]);


	// Définition des routes
	function cdRoutes($routeProvider) {
		$routeProvider.when('/cd', {
			templateUrl: 'cd/cd.html'
		});
	}

})();
