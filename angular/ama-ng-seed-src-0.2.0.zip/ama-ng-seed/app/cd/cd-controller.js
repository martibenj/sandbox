(function () {
	'use strict';

	/**
	 * Déclaration du module des CDs
	 */
	angular.module('app.cd-controller', ['ngRoute'])
		.controller('CdController', ['$rootScope', CdController]);


	// Implémentation du controleur
	function CdController($rootScope) {
		var vm = this;
		vm.label = 'A vous de terminer !';
		$rootScope.titrePage = "Application exemple - CD";
	}
})();
