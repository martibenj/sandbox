exports.config = {
	//Navigateur
	multiCapabilities: [
		{
			browserName: 'firefox'
		}
		//,
		//{
		//	browserName: 'chrome'
		//}
	]
};
